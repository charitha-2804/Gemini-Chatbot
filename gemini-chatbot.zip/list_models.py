import google.generativeai as genai
from dotenv import load_dotenv
import os

load_dotenv()
api_key = os.getenv("GEMINI_API_KEY")
print("API Key loaded:", bool(api_key))

genai.configure(api_key=api_key)

print("\nAvailable models for generate_content():")
for m in genai.list_models():
    # Access current supported methods
    methods = getattr(m, "supported_generation_methods", None)
    print("-", m.name, "| methods:", methods)
