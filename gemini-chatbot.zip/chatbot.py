import google.generativeai as genai
import os

# Load API key from environment variable
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
genai.configure(api_key=GOOGLE_API_KEY)

# Load the Gemini Pro model
model = genai.GenerativeModel("gemini-pro")

def get_gemini_response(message):
    try:
        response = model.generate_content(message)
        return response.text
    except Exception as e:
        print(f"Gemini API error: {e}")
        return "Error processing your request."