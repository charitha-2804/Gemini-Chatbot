from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
from dotenv import load_dotenv
import os
import google.generativeai as genai

# Load API Key
load_dotenv()
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

# Configure Gemini
genai.configure(api_key=GEMINI_API_KEY)
model = genai.GenerativeModel("models/gemini-1.5-flash")

# Flask Setup
app = Flask(__name__)
CORS(app)

@app.route("/")
def home():
    return render_template("chatbot.html")

@app.route("/chat", methods=["POST"])
def chat():
    try:
        user_input = request.json.get("message", "")
        response = model.generate_content(user_input)
        reply = response.text.strip()
        return jsonify({"response": reply})
    except Exception as e:
        import traceback
        traceback.print_exc()  # 🔍 This will show the real error
        return jsonify({"response": f"Error: {str(e)}"}), 500
if __name__ == "__main__":
    app.run(debug=True)
